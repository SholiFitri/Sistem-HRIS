export { KTScrollto } from './scrollto';
export type { KTScrolltoConfigInterface, KTScrolltoInterface } from './types';
