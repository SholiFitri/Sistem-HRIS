export { KTMenu } from './menu';
export type { KTMenuConfigInterface, KTMenuInterface } from './types';
