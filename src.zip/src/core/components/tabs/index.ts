export { KTTabs } from './tabs';
export type { KTTabsConfigInterface, KTTabsInterface } from './types';
