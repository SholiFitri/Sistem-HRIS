const config = {
	useTabs: true,
	tabWidth: 2,
	singleQuote: true,
	bracketSameLine: true,
	arrowParens: 'always',
};

module.exports = config;